#ifndef EXPLOSION_H
#define EXPLOSION_H

char *explode(char * s, int k);

#endif /*EXPLOSION_H*/
