/*
 * NAME: 
 * ID:
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


char *explode(char * s, int k) {
  // TODO: IMPLEMENT ME
  return NULL;
}
